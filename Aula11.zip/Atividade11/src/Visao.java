class Visao {
    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        int[] array = {54, 26, 93, 17, 77, 31, 44, 55, 20, 65};
        Arrays.sort(array);

        modelo.setNumeros(array);

        int numeroParaEncontrar = 31;
        Controle controle = new Controle();
        int resultado = controle.buscarNumero(modelo.getNumeros(), numeroParaEncontrar);

        if (resultado == -1) {
            System.out.println("Elemento " + numeroParaEncontrar + " não encontrado.");
        } else {
            System.out.println("Elemento " + numeroParaEncontrar + " encontrado no índice " + resultado);
        }
    }
}