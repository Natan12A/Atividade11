import java.util.Arrays;

// Classe modelo
class Modelo {
    private int[] numeros;

    public Modelo() {
        numeros = new int[10];
    }

    public void setNumeros(int[] numeros) {
        this.numeros = numeros;
    }

    public int[] getNumeros() {
        return numeros;
    }
}